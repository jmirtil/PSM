package my.PSM.PSM_Storage;


import java.util.ArrayList;

import my.PSM.PSM_Interface.LoginForm;
import my.PSM.PSM_Interface.MainMenu;
import my.PSM.PSM_Interface.Messages;
import my.PSM.PSM_Interface.PrefilledScheduleForm;
import my.PSM.PSM_Interface.ScheduleForm;
import my.PSM.PSM_Interface.courseSelect;
import my.PSM.PSM_Logic.Authenticate;
import my.PSM.PSM_Logic.InterfaceController;
import my.PSM.PSM_Logic.appController;
/*Date: 6-12-2016
 *UrTgwrKxznxbkt
 */
public class Storage_Facade {
	//DBConnection dbCon = new DBConnection();
	static DBConnection myManager = new DBConnection();
	appController app = new appController();
	InterfaceController ic = new InterfaceController();
	Messages msg = new Messages();
	ScheduleForm sched = new ScheduleForm();
	PrefilledScheduleForm preSched = new PrefilledScheduleForm();
	LoginForm login = new LoginForm();
	Authenticate auth;
	MainMenu menu = new MainMenu();
	courseSelect cs;
	
	public int connect(String username, String password) {	
		//return dbCon.connect(username, password);
		return myManager.connect(username, password);
	}	
	public int disconnect() {
		return myManager.disconnect();
	}	
	//This method is never called.
	public int fetchCourseID(int courseId) {
		return myManager.fetchCourseID(courseId);
	}
	public ArrayList<String> getEndDates() {
		return myManager.getEndDates();
	}
	public String fetchCourses() {
		//return dbCon.fetchCourses();
		return myManager.fetchCourses().toString();
	}
	public String fetchCourseSubj(int courseId) {
		//return dbCon.fetchCourseSubj(courseId);
		return myManager.fetchCourseSubj(courseId);
	}
	public String fetchCourseName(int courseId) {
		//return dbCon.fetchCourseName(courseId);
		return myManager.fetchCourseName(courseId);
	}
	public String fetchCourseSemester(int courseId) {
		//return dbCon.fetchCourseSemester(courseId);
		return myManager.fetchCourseSemester(courseId);
	}
	public String fetchCourseStart(int courseId) {
		//return dbCon.fetchCourseStart(courseId);
		return myManager.fetchCourseStart(courseId);
	}
	public String fetchCourseEnd(int courseId) {
		//return dbCon.fetchCourseEnd(courseId);
		return myManager.fetchCourseEnd(courseId);
	}
	public String fetchStartMon(int courseId) {
		//return dbCon.fetchStartMon(courseId);
		return myManager.fetchStartMon(courseId);
	}
	public String fetchEndMon(int courseId) {
		//return dbCon.fetchEndMon(courseId);
		return myManager.fetchEndMon(courseId);
	}
	public String fetchStartTue(int courseId) {
		//return dbCon.fetchStartTue(courseId);
		return myManager.fetchStartTue(courseId);
	}
	public String fetchEndTue(int courseId) {
		//return dbCon.fetchEndTue(courseId);
		return myManager.fetchEndTue(courseId);
	}
	public String fetchStartWed(int courseId) {
		//return dbCon.fetchStartWed(courseId);
		return myManager.fetchStartWed(courseId);
	}
	public String fetchEndWed(int courseId) {
		//return dbCon.fetchEndWed(courseId);
		return myManager.fetchEndWed(courseId);
	}
	public String fetchStartThu(int courseId) {
		//return dbCon.fetchStartThu(courseId);
		return myManager.fetchStartThu(courseId);
	}
	public String fetchEndThu(int courseId) {
		//return dbCon.fetchEndThu(courseId);
		return myManager.fetchEndThu(courseId);
	}
	public String fetchStartFri(int courseId) {
		//return dbCon.fetchStartFri(courseId);
		return myManager.fetchStartFri(courseId);
	}
	public String fetchEndFri(int courseId) {
		//return dbCon.fetchEndFri(courseId);
		return myManager.fetchEndFri(courseId);
	}
	public String fetchStartSat(int courseId) {
		//return dbCon.fetchStartSat(courseId);
		return myManager.fetchStartSat(courseId);
	}
	public String fetchEndSat(int courseId) {
		//return dbCon.fetchEndSat(courseId);
		return myManager.fetchEndSat(courseId);
	}
	public void clearDatabase() {
		myManager.clearDatabase();
	}
	public void createClassTable() {
		//This is empty, since the method is never called. 
	}
	public ArrayList<Integer> getCourses() {
		return myManager.getCourses();
	}
	public void setAck(boolean flag) {
		Messages.ack = flag;
	}
	public boolean getAck () {
		return Messages.ack;
	}
	public boolean validateLogin() {
		return auth.validate_Login();
	}
	public boolean logout() {
		return auth.logout();
	}
	public void authenticate() {
		auth = new Authenticate(getUserName(), getPassword());
	}
	public void setDataRec(boolean param) {
		login.setDataRec(param);
	}
	public boolean dataReceived(){
		return login.dataReceived();
	}
	public void loginlaunchForm() {
		login.launchForm();
	}
	public String getUserName() {
		return login.getUsername();
	}
	public String getPassword(){
		return login.getPassword();
	} 
	//Messages class method calls
	public void initiateLogOut() {
		msg.logoutConfirmation();
	}
	public void incorrectLogin() {
		msg.incorrectLogin();
	}
	public void passwordLock() {
		msg.lockedOut();
	}
	public void fiveMinWarning() {
		msg.FiveMinWarning();
	}
	public void fifteenMinWarning() {
		msg.FifteenMinWarning();
	}	
	public void endClassWarning() {
		msg.endClassWarning();
	}
	public void Pre_Filled_Form(int courseID, String courseSubj, String courseName, String semester,
            String startDate, String endDate, String startMon, String endMon,
            String startTue, String endTue, String startWed, String endWed, String startThu, String endThu, 
            String startFri, String endFri, String startSat, String endSat) 
    {  
         preSched.launchEdit(courseID, courseSubj, courseName, semester,
            startDate, endDate, startMon, endMon, startTue, endTue, 
            startWed, endWed, startThu, endThu, startFri, endFri, startSat, endSat);
    }
	public void courseSelectForm() {
		cs = new courseSelect();
		cs.launchCourse();
	}
	public boolean getCourseSelected() {
		return cs.courseSelected();
	}
	public void setCourseSelected(boolean param) {
		cs.setCourseSelected(param);
	}
	public int getSelection() {
		return cs.getSelection();
	}
	//schedule method calls
	public void launchInitial() {
		sched.launchInitial();
	}
	public boolean schedDataRec() {
		return sched.dataRec();
	}
	public void schedSetDataRec(boolean param) {
		sched.setDataRec(param);
	}
	//Main Menu methods
	public void initiateMainMenu() {
		menu.launchForm();
	}
	public boolean getMainMenuDataRec(){
		return menu.dataRec();
	}
	public boolean getMainMenuEditSchedSelected() {
		return menu.editSchedSelected();
	}
	public boolean mainMenuInitSetUpSelected() {
		return menu.InitSetupSelected();
	}
	public boolean mainMenuLogOutSelected() {
		return menu.logoutSelected();
	}
	public void mainMenuSetDataRec(boolean flag) {
		menu.setdataRec(flag);
	}
	//Store methods
	public int storeClassInfo(int courseID, String courseSubj, String courseName, String semester) {
		return myManager.storeClassInfo(courseID, courseSubj, courseName, semester);
	}
	public int storeClassSched(){
		return myManager.storeClassSched(scheduleGetNewCourseId(), scheduleGetNewCourseStart(),
				scheduleGetNewCourseEnd(), scheduleGetNewMonStart(), scheduleGetNewMonEnd(),
				scheduleGetNewTueStart(), scheduleGetNewTueEnd(), scheduleGetNewWedStart(),
				scheduleGetNewWedEnd(), scheduleGetNewThuStart(), scheduleGetNewThuEnd(),
				scheduleGetNewFriStart(), scheduleGetNewFriEnd(), scheduleGetNewSatStart(),
				scheduleGetNewSatEnd());
	}
	public static int storePreClassSched() {
		return myManager.storeClassSched(PrefilledScheduleForm.getDefCourseID(),
				PrefilledScheduleForm.getNewCourseStart(),PrefilledScheduleForm.getNewCourseEnd(), 
				PrefilledScheduleForm.getNewMonStart(),	PrefilledScheduleForm.getNewMonEnd(), 
				PrefilledScheduleForm.getNewTueStart(),	PrefilledScheduleForm.getNewTueEnd(), 
				PrefilledScheduleForm.getNewWedStart(),	PrefilledScheduleForm.getNewWedEnd(),
				PrefilledScheduleForm.getNewThuStart(),	PrefilledScheduleForm.getNewThuEnd(),
				PrefilledScheduleForm.getNewFriStart(),	PrefilledScheduleForm.getNewFriEnd(),
				PrefilledScheduleForm.getNewSatStart(),	PrefilledScheduleForm.getNewSatEnd());
	}
	//Schedule get method calls.
	public int scheduleGetNewCourseId(){
		return ScheduleForm.getNewCourseID();
	}
	public String scheduleGetNewSub(){
		return ScheduleForm.getNewSub();
	}
	public String scheduleGetNewCourseName(){
		return ScheduleForm.getNewCourseName();
	}
	public String scheduleGetNewSemester(){
		return ScheduleForm.getNewSemester();
	}
	public String scheduleGetNewCourseStart(){
		return ScheduleForm.getNewCourseStart();
	}
	public String scheduleGetNewCourseEnd(){
		return ScheduleForm.getNewCourseEnd();
	}
	public String scheduleGetNewMonStart(){
		return ScheduleForm.getNewMonStart();
	}
	public String scheduleGetNewMonEnd(){
		return ScheduleForm.getNewMonEnd();
	}
	public String scheduleGetNewTueStart(){
		return ScheduleForm.getNewTueStart();
	}
	public String scheduleGetNewTueEnd(){
		return ScheduleForm.getNewTueEnd();
	}
	public String scheduleGetNewWedStart(){
		return ScheduleForm.getNewWedStart();
	}
	public String scheduleGetNewWedEnd(){
		return ScheduleForm.getNewWedEnd();
	}
	public String scheduleGetNewThuStart(){
		return ScheduleForm.getNewThuStart();
	}
	public String scheduleGetNewThuEnd(){
		return ScheduleForm.getNewThuEnd();
	}
	public String scheduleGetNewFriStart(){
		return ScheduleForm.getNewFriStart();
	}
	public String scheduleGetNewFriEnd(){
		return ScheduleForm.getNewFriEnd();
	}
	public String scheduleGetNewSatStart(){
		return ScheduleForm.getNewSatEnd();
	}
	public String scheduleGetNewSatEnd(){
		return ScheduleForm.getNewTueEnd();
	}
}
