/*
 * Authenticate.java
 *
 * Created on April 8, 2008, 3:25 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package my.PSM.PSM_Logic;

//import my.PSM.PSM_Storage.DBConnection;
import my.PSM.PSM_Storage.Storage_Facade;

/**
 *
 * @author lrizo002
 */
public class Authenticate {
    
    String username;
    String password;
    //DBConnection db;
    Storage_Facade myFacade;
    /** Creates a new instance of Authenticate */
    public Authenticate(String user, String pw) {
        username = user;
        password = pw;
        //db = new DBConnection();
        myFacade = new Storage_Facade();
    }
    
    public boolean validate_Login()
    {
        int state; 
        state = myFacade.connect(username, password);
        //state = db.connect(username,password);          // connect to default database
        if(state == 0)
            return true;
        else
            return false;   
    }
    
    public boolean logout()
    {
        int state;
        //state = db.disconnect();
        state = myFacade.disconnect();
        if(state == 0)
            return true;
        else
            return false;
    }
    
}
